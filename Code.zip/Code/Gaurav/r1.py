dict1 = {'AILA_Q1': 4,
 'AILA_Q2': 3,
 'AILA_Q3': 4,
 'AILA_Q4': 4,
 'AILA_Q5': 5,
 'AILA_Q6': 5,
 'AILA_Q7': 4,
 'AILA_Q8': 5,
 'AILA_Q9': 5,
 'AILA_Q10': 5,
 'AILA_Q11': 4,
 'AILA_Q12': 4,
 'AILA_Q13': 5,
 'AILA_Q14': 5,
 'AILA_Q15': 4,
 'AILA_Q16': 5,
 'AILA_Q17': 2,
 'AILA_Q18': 4,
 'AILA_Q19': 5,
 'AILA_Q20': 4,
 'AILA_Q21': 4,
 'AILA_Q22': 5,
 'AILA_Q23': 5,
 'AILA_Q24': 5,
 'AILA_Q25': 5,
 'AILA_Q26': 5,
 'AILA_Q27': 4,
 'AILA_Q28': 4,
 'AILA_Q29': 4,
 'AILA_Q30': 5,
 'AILA_Q31': 5,
 'AILA_Q32': 4,
 'AILA_Q33': 4,
 'AILA_Q34': 5,
 'AILA_Q35': 5,
 'AILA_Q36': 5,
 'AILA_Q37': 4,
 'AILA_Q38': 4,
 'AILA_Q39': 5,
 'AILA_Q40': 4,
 'AILA_Q41': 5,
 'AILA_Q42': 5,
 'AILA_Q43': 5,
 'AILA_Q44': 4,
 'AILA_Q45': 4,
 'AILA_Q46': 4,
 'AILA_Q47': 5,
 'AILA_Q48': 5,
 'AILA_Q49': 4,
 'AILA_Q50': 3}

arr = [0]*23
s = 0

for key in dict1.keys():
	arr[dict1[key]] += 1
	s += dict1[key]

print("mean = " + str(s/50))

for i in range(23):
	if arr[i] != 0:
		print(str(i) + " " + str(arr[i]))