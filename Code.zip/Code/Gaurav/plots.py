# importing library
import matplotlib.pyplot as plt
  
# function to add value labels
def addlabels(x,y):
    for i in range(len(x)):
        plt.text(i,y[i],y[i])
  
if __name__ == '__main__':
    # creating data on which bar chart will be plot
    x = ["Okapi\nBM25", "TF-IDF", "Sentence\nBERT", "Law BERT", "RM1", "AILA\nBEST"]
    y = [0.09023293871, 0.01978923391, 0.006292999869, 0.03511904311, 0.1139860649, 0.1266]

    # making the bar chart on the data
    barlist = plt.bar(x, y)
    barlist[5].set_color('g')  
    # calling the function to add value labels
    addlabels(x, y)
      
    # giving title to the plot
    plt.title("MAP")
      
    # giving X and Y labels
    plt.xlabel("Methods")
    plt.ylabel("Values")
      
    # visualizing the plot
    plt.show()
